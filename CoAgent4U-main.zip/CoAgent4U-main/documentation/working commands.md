show my schedule

